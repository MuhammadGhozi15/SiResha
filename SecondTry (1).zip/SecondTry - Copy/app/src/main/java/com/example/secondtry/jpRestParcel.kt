package com.example.secondtry

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class jpRestParcel(

    val jpImgRes: Int,
    val jpNameRes: String,
    val jpDescRes: String,

) : Parcelable

package com.example.secondtry

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.ImageView

class LobbyActivity : AppCompatActivity(), View.OnClickListener {

    private lateinit var jp: ImageView
    private lateinit var kr: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lobby)

        jp = findViewById(R.id.jpn_flag)
        jp.setOnClickListener(this)

        kr = findViewById(R.id.kr_flag)
        kr.setOnClickListener(this)


    }

    override fun onClick(v: View) {
        when (v.id) {
            R.id.jpn_flag -> {
                val jp_cats = Intent(this@LobbyActivity, JpnResActivity::class.java)
                startActivity(jp_cats)
            }
            R.id.kr_flag -> {
                val kr_cats = Intent(this@LobbyActivity, KrResActivity::class.java)
                startActivity(kr_cats)
            }
        }
    }
}
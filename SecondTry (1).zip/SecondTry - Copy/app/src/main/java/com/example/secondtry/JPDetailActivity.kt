package com.example.secondtry

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView

class JPDetailActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_jpdetail)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val dtlRest = intent.getParcelableExtra<jpRestParcel>(JpnResActivity.INTENT_PARCELABLE)

        val dtlJpImgRes = findViewById<ImageView>(R.id.img_item_photo)
        val dtlJpNameRes = findViewById<TextView>(R.id.tv_item_name)
        val dtlJpDescRes = findViewById<TextView>(R.id.tv_item_description)

        dtlJpImgRes.setImageResource(dtlRest?.jpImgRes!!)
        dtlJpNameRes.text = dtlRest.jpNameRes
        dtlJpDescRes.text = dtlRest.jpDescRes


    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
}
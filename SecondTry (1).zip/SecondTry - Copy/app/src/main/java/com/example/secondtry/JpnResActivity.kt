package com.example.secondtry

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class JpnResActivity : AppCompatActivity() {

    companion object {
        val INTENT_PARCELABLE = "OBJECT_INTENT"
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_jpn_res)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val restoList = listOf<jpRestParcel>(
            jpRestParcel(
                R.drawable.sushiken,
                "Sushiken Asakusa",
                "Asakusa Sushi-Ken is the first-made Halal Sushi restaurant in Tokyo\n\n" +
                        "Alamat : Asakusa, Taito City, Tokyo\n\n" +
                        "Buka : 12.00-15.00 dan 17.00-22.30 (Senin-Sabtu)12.00-15.00 dan 17.00-22.00 (Minggu)"
            ),
            jpRestParcel(
                R.drawable.malaychan,
                "Malaychan",
                "Malaychan is the first and only restaurant that certified as an official Halal restaurant by the Malaysian Islam\n\n" +
                        "Alamat : 3 Chome-22-6 Nishi-ikebukuro, Toshima-ku, Tokyo\n\n" +
                        "Buka : 17.00-23.00 (Senin)11.00-12.30 dan 17.00-23.00 (Selasa-Kamis)11.00-12.30 dan 17.00-tengah malam (Jumat-Sabtu)11.00-23.00 (Minggu)"
            ),
            jpRestParcel(
                R.drawable.gyumon,
                "Gyumon",
                "gyumon is a halal yakiniku restaurant located in shibuya, japan\n\n" +
                        "Alamat : 3 Chome-14-5 Shibuya, Shibuya-ku, Tokyo\n\n" +
                        "Buka : 17.00-04.00 (Senin-Sabtu)17.00-23.00 (Minggu)"
            ),
            jpRestParcel(
                R.drawable.kusumoto,
                "Kusumoto",
                "Authentic Japanese restaurant offers halal menus and lunch box\n\n" +
                        "Alamat : 3-23-5, Nishi-Azabu, Minatoku, Tokyo\n\n" +
                        "Buka : 18.00-23.00 (Senin-Sabtu)"
            ),
            jpRestParcel(
                R.drawable.naritayaosaka,
                "Naritaya",
                "The restaurant provides fresh noodles (uses domestic wheat) that are being made at their own factory.\n\n" +
                        "Alamat : 1 Chome-11-7 Shinjuku, Tokyo\n\n" +
                        "Buka : 14.00-22.00 (Senin-Kamis)18.00-22.00 (Jumat)13.00-22.00 (Sabtu, Minggu, Hari Libur)"
            ),
            jpRestParcel(
                R.drawable.sekai,
                "Sekai Cafe",
                "Sekai cafe is a halal whose main menu is chicken steak, sirloin steak and lamb steak.\n\n" +
                        "Alamat : 1 Chome-18-8 Asakusa, Taito, Tokyo\n\n" +
                        "Buka : 9.30-22.00 setiap hari kecuali libur nasional"
            ),
            jpRestParcel(
                R.drawable.kappo,
                "Kappo Suruga",
                "We welcome all muslims who's looking for real delicious and traditional Japanese cuisine with certification of Muslim Friendly restaurant and HALAL Menu Authentication.\n\n" +
                        "Alamat : 1-12, Shin-machi, Chuo-ku, Chiba-city, Chiba\n\n" +
                        "Buka : 11.30-14.00 dan 17.00-22.30 (Senin-Jumat)17.00-22.00 (Sabtu)"
            ),
            jpRestParcel(
                R.drawable.yama,
                "Kappou YAMA",
                "Kappou Yama has developed Halal ramen in an attempt to overcome this situation.\n\n" +
                        "Alamat : 3-15-1 Uemine, Chuo-ku, Saitama-shi, Saitama\n\n" +
                        "Buka : 07.00-21.0 (Selasa-Minggu)"
            ),
            jpRestParcel(
                R.drawable.sumiyakia,
                "Sumiyakiya",
                "sumiyakiya provides the Harumon. Horumon is a type of Japanese cuisine with roots from Joseon food culture, so you can enjoy dishes like kimchi , Korean pancakes and bibimbap\n\n" +
                        "Alamat : 3-29-16, Nishiazabu, Minato-ku, Tokyo\n\n" +
                        "Buka : 11.30-15.00 dan 18.00-23.30 (Senin-Jumat)18.00-23.30 (Sabtu)"
            ),
            jpRestParcel(
                R.drawable.hanasakaji,
                "Hanasakaji-san",
                "The main menu is Japanese-style shabu-shabu which is fresh and super delicious. In addition, the meat served has received halal certification from a local institution.\n\n" +
                        "Alamat : 3 Chome-14-5 Shibuya, Shibuya-ku, Tokyo-to B1F\n\n" +
                        "Buka : 10.30-15.00 dan 17.00-tengah malam (Senin-Jumat)17.00-tengah malam (Sabtu-Minggu)"
            ),
            jpRestParcel(
                R.drawable.minokichi,
                "Minokichi Tobu Ikebukuro",
                "Minokichi Tobu Ikebukuro is the next restaurant in Tokyo to serve halal cuisine. One of the unique offerings from this place is the typical Muslim-friendly Kyoto menus.\n\n" +
                        "Alamat : Spice Ikebukuro Tobu 15F, 1-1-25, Nishi Ikebukuro, Toshima-ku, Tokyo\n\n" +
                        "Buka : 11.00-23.00 (Senin-Sabtu)11.00-22.00 (Minggu dan Hari Libur)"
            ),
            jpRestParcel(
                R.drawable.takaraya,
                "Takaraya",
                "This restaurant is located in Chiba and serves dinner and lunch menus. To guarantee halalness, Takaraya uses halal-certified cooking ingredients and special cooking utensils.\n\n" +
                        "Alamat : 2-3-4, Chuo, Kisarazu-city, Chiba\n\n" +
                        "Buka : 11.30-14.00 dan 17.00-22.00 (Senin-Sabtu)11.30-14.30 dan 17.00-21.00 (Minggu dan Hari Libur)"
            ),
        )

        val recyclerView = findViewById<RecyclerView>(R.id.rv_rest)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.setHasFixedSize(true)
        recyclerView.adapter = RestoAdapter(this, restoList){
            val intent = Intent (this, JPDetailActivity::class.java)
            intent.putExtra(INTENT_PARCELABLE, it)
            startActivity(intent)

        }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
}
package com.example.secondtry

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class krRestParcel(

    val krImgRes: Int,
    val krNameRes: String,
    val krDescRes: String,

) : Parcelable

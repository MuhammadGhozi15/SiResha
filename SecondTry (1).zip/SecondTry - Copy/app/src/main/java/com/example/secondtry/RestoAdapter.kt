package com.example.secondtry

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class RestoAdapter(private val context: Context, private val resto: List<jpRestParcel>, val listener: (jpRestParcel) -> Unit)
    :RecyclerView.Adapter<RestoAdapter.RestoViewHolder>() {

    class RestoViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val jpAdpImgRes = view.findViewById<ImageView>(R.id.img_item_photo)
        val jpAdpNameRes = view.findViewById<TextView>(R.id.res_dsg_name)
        val jpAdpDescRes = view.findViewById<TextView>(R.id.res_dsg_description)

        fun bindView(resto: jpRestParcel, listener: (jpRestParcel) -> Unit){
            jpAdpImgRes.setImageResource(resto.jpImgRes)
            jpAdpNameRes.text = resto.jpNameRes
            jpAdpDescRes.text = resto.jpDescRes
            itemView.setOnClickListener{
                listener(resto)
            }

        }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RestoViewHolder {
        return RestoViewHolder(LayoutInflater.from(context).inflate(R.layout.card_dsg, parent, false))
    }

    override fun onBindViewHolder(holder: RestoViewHolder, position: Int) {
        holder.bindView(resto[position], listener)
    }

    override fun getItemCount(): Int = resto.size
}
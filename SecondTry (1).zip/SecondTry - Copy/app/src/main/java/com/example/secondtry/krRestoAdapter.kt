package com.example.secondtry

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class krRestoAdapter(private val context: Context, private val krResto : List<krRestParcel>, val listener: (krRestParcel) -> Unit)
    :RecyclerView.Adapter<krRestoAdapter.krRestoviewHoolder>() {

    class krRestoviewHoolder(view: View):RecyclerView.ViewHolder(view) {

        val krAdpImgRes = view.findViewById<ImageView>(R.id.img_item_photo)
        val krAdpNameRes = view.findViewById<TextView>(R.id.res_dsg_name)
        val krAdpDescRes = view.findViewById<TextView>(R.id.res_dsg_description)

        fun bindView(krResto: krRestParcel, listener: (krRestParcel) -> Unit){

            krAdpImgRes.setImageResource(krResto.krImgRes)
            krAdpNameRes.text = krResto.krNameRes
            krAdpDescRes.text = krResto.krDescRes
            itemView.setOnClickListener{
                listener(krResto)
            }

        }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): krRestoviewHoolder {
        return krRestoviewHoolder(
            LayoutInflater.from(context).inflate(R.layout.card_dsg, parent, false)
        )
    }

    override fun onBindViewHolder(holder: krRestoviewHoolder, position: Int) {
        holder.bindView(krResto[position], listener)
    }

    override fun getItemCount(): Int = krResto.size
}
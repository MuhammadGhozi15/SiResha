package com.example.secondtry

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class KrResActivity : AppCompatActivity() {

    companion object {
        val INTENT_PARCELABLE = "OBJECT_INTENT"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_kr_res)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val krRestoList = listOf<krRestParcel>(
            krRestParcel(
                R.drawable.yell,
                "Yell-O! Chicken",
                "First Halal Chicken in Korea!\n\n" +
                        "Alamat : 14 Usadan-ro 10-gil, Itaewon 1(il)-dong, Yongsan-gu, Seoul, South Korea\n\n" +
                        "Buka : Monday - Friday 11:00 AM - 11:00 PM\n" +
                        "Saturday & Sunday 11:00 AM - 11:00 PM"
            ),
            krRestParcel(
                R.drawable.murree,
                "Murree",
                "We give Muslim diners a real taste of traditional Korean food.\n\n" +
                        "Alamat : South Korea, 서울특별시 용산구 이태원1동 우사단로10길 20\n\n" +
                        "Ditutup Permanen"
            ),
            krRestParcel(
                R.drawable.busan,
                "Busan Jib",
                "You can find halal Korean food in Myeongdong at this Halal restaurant Busan Jib Halal Food!\n\n" +
                        "Alamat : 11-4, 8 Myeongdong-gil, Jung-gu, Seoul 04536 Korea Selatan\n\n" +
                        "Buka : Seiap hari 10:00 AM - 10:00 Pm"
            ),krRestParcel(
                R.drawable.eid,
                "EID – 이드 Halal Korean Food",
                "Try their authentic Korean dishes like bibimbap, bulgogi, and banchan, and you'll definitely understand why EID is one of the most popular halal restaurants in South Korea!\n\n" +
                        "Alamat : 67, Usadan-ro 10-gil, Yongsan-gu, Seoul 04408 Korea Selatan\n\n" +
                        "Buka : Selasa - Minggu 11.30 - 21.00"
            ),krRestParcel(
                R.drawable.makan,
                "Makan Halal Restaurant",
                "This restaurant located in the Itaewon area has a selection of local dishes such as beef bulgogi, dakdoritang (spicy boiled chicken), mulnaengmyeon (cold noodles), and more.\n\n" +
                        "Alamat : 52 Usadan-ro 10 gil, Yongsan-gu, Seoul 04407 Korea Selatan\n\n" +
                        "Buka : Rabu - Senin 10.30 - 22.00"
            ),krRestParcel(
                R.drawable.halal,
                "Halal Kitchen Korea",
                "Halal Kitchen Korea is the perfect resting place for Muslim travelers in Seoul.\n\n" +
                        "Alamat : 86-4, Samcheong-ro, Jongno-gu, Seoul 03053 Korea Selatan\n\n" +
                        "Buka : Rabu - Senin 12:00 PM - 3:00 PM dan 5:00 PM - 8:00 PM"
            ),krRestParcel(
                R.drawable.chunja,
                "Chunja Daegutang",
                "Chunja Daegutang takes cod as its main ingredient and turns it into delicious dishes such as daegu-ppoljjim (cod head) to daegu-jeongol (cod fish hotpot).\n\n" +
                        "Alamat : 375-5, Seogyo-dong, Mapo-gu, Seoul Korea Selatan\n\n" +
                        "Buka : Senin - Sabtu 11.00 - 22.00"
            ),krRestParcel(
                R.drawable.oseg,
                "Osegyehyang",
                "Located in Insadong, you can dine casually and try some of their plant-based dishes like ttukbulgui (vegan meat served in a stone bowl), bulgui deopbap (vegan rice and meat) and more!\n\n" +
                        "Alamat : 14-5, Insadong 12-gil, Jongno-gu, Seoul 03146 Korea Selatan\n\n" +
                        "Buka : Senin - Jumat 11.30-21.00 \n" +
                        "Sabtu-Minggu 11.00-16.00 dan 17.00-21.00"
            ),
        )

        val recyclerView = findViewById<RecyclerView>(R.id.krv_rest)
        recyclerView.layoutManager=LinearLayoutManager(this)
        recyclerView.setHasFixedSize(true)
        recyclerView.adapter = krRestoAdapter(this, krRestoList){
            val intent = Intent (this, KRDetailActivity::class.java)
            intent.putExtra(INTENT_PARCELABLE, it)
            startActivity(intent)

        }


    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
}
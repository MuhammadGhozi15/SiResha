package com.example.secondtry

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView

class KRDetailActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_krdetail)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val dtlRest = intent.getParcelableExtra<krRestParcel>(KrResActivity.INTENT_PARCELABLE)

        val dtlKrImgRes = findViewById<ImageView>(R.id.img_item_photo)
        val dtlKrNameRes = findViewById<TextView>(R.id.tv_item_name)
        val dtlKrDescRes = findViewById<TextView>(R.id.tv_item_description)

        dtlKrImgRes.setImageResource(dtlRest?.krImgRes!!)
        dtlKrNameRes.text = dtlRest.krNameRes
        dtlKrDescRes.text = dtlRest.krDescRes
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
}